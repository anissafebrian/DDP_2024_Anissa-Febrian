from Gempa import *

gempa1 = Gempa('Banten', 1.2)
gempa1.dampak()

gempa1 = Gempa('Palu', 6.1)
gempa1.dampak()

gempa1 = Gempa('Cianjur', 5.6)
gempa1.dampak()

gempa1 = Gempa('Jayapura', 3.3)
gempa1.dampak()

gempa1 = Gempa('Garut', 4)
gempa1.dampak()

